package com.gernera.app.suites;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.gernera.app.tests.TestsSequence;

@RunWith(Suite.class)
@SuiteClasses({ TestsSequence.class })
public class TestsSuiteSequence {

}
