package com.gernera.app.tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.gernera.utils.Constants;
import com.gernera.utils.PasswordValidator;
import com.gernera.utils.RegexpPrecompileSingleton;

public class TestsRegExp {
	LinkedHashSet<Pattern> regexpSetPrecompile = null;
	 @Before
	    public void init() {
		 	List<String> regexpList = new ArrayList<String>();
			regexpList.add(Constants.regexpLengthAndOccurrence);
			regexpList.add(Constants.regexpOnlyDigitsAndLowCase);
			RegexpPrecompileSingleton regexpPrecompileSingleton = RegexpPrecompileSingleton.getInstance(regexpList);
	      	regexpSetPrecompile=regexpPrecompileSingleton.precompiledRegexpSet;
	      	
	 }

	@Test 
	public void validateRegExpConditionPasswordIsNull() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName+"- password is null");
	    	String password=null;
	    	Assert.assertFalse(new PasswordValidator().validateRegExp(password, regexpSetPrecompile));
	    }
	    @Test
	    public void validateRegExpConditionPasswordIsEmpty() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName+"- password is empty");
	    	String password="";
	    	Assert.assertFalse(new PasswordValidator().validateRegExp(password, regexpSetPrecompile));
	    }
	    @Test
	    public void validateRegExpRegExpIsNull() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName+"- regexp is null");
	    	String password="12345";
	    	Assert.assertFalse(new PasswordValidator().validateRegExp(password, regexpSetPrecompile));
	    }
	    @Test
	    public void validateRegExpRegExpIsEmpty() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName+"- regexp is empty");
	    	String password="12345";
	    	Assert.assertFalse(new PasswordValidator().validateRegExp(password, regexpSetPrecompile));
	    }
	   
	    @Test
	    public void validateRegExpPwdWithinRangeAndGood() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName+"- password is 7 and correct");
	    	String password="a12456b";
	    	Assert.assertTrue(new PasswordValidator().validateRegExp(password, regexpSetPrecompile));
	    }
	    @Test
	    public void validateRegExpPwdAboveUppeBorderAndGood() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName+"- password > 12");
	    	String password="a1234567891a2345";
	    	Assert.assertFalse(new PasswordValidator().validateRegExp(password, regexpSetPrecompile));
	    }
	    @Test
	    public void validateRegExpPwdOnLowBorderAndGood() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName+"- password = 5 and correct");
	    	String password="a1234";
	    	Assert.assertTrue(new PasswordValidator().validateRegExp(password, regexpSetPrecompile));
	    }
	    @Test
	    public void validateRegExpPwdBelowLowBorderAndGood() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName+"- password < 5 and correct");
	    	String password="a123";
	    	Assert.assertFalse(new PasswordValidator().validateRegExp(password, regexpSetPrecompile));
	    }
	    @Test
	    public void validateRegExpCapitalLetters() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName+"- pasword with Capital Letter");
	    	String password="a123SD";
	    	Assert.assertFalse(new PasswordValidator().validateRegExp(password, regexpSetPrecompile));
	    }
	    @Test
	    public void validateRegExpSpecialCharacters() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName+"- password with Special Characters");
	    	String password="a123//%";
	    	Assert.assertFalse(new PasswordValidator().validateRegExp(password, regexpSetPrecompile));
	    } 
}
