package com.gernera.app.tests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.gernera.utils.PasswordValidator;

public class TestsSequence {
	public void testValidateSequencePasswordIsNull() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + "- password is null");
		String password = null;
		Assert.assertFalse(new PasswordValidator().validateSequence(password));
	}

	@Test
	public void testValidateSequencePasswordIsEmpty() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + "- password is empty");
		String password = "";
		Assert.assertFalse(new PasswordValidator().validateSequence(password));
	}

	@Test
	public void testValidateSequenceRepeatedCondition() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + "- repeated sequence included");
		String password = "abc1c123ab";
		Assert.assertFalse(new PasswordValidator().validateSequence(password));
	}

	@Test
	public void testValidateSequenceNoRepeatedCondition() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + "- repeated sequence not included");
		String password = "abc123ab";
		Assert.assertTrue(new PasswordValidator().validateSequence(password));
	}
}
