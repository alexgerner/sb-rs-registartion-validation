package com.gernera.app;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

import com.gernera.utils.Constants;
import com.gernera.utils.PasswordValidator;
import com.gernera.utils.RegexpPrecompileSingleton;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("Authentication Service")
public class AuthenticationService {
	private static final Logger logger = LoggerFactory.getLogger(AuthenticationService.class);
	@Autowired
	private ApplicationProperties applicationProperties;
	public synchronized String executeService(String loginName, String pwd) {
		List<String> regexpList = applicationProperties.getRegexp();
		if (loginName.equals(Constants.defaultLoginName) || pwd.equals(Constants.defaultPassword)) {
			return Constants.messageProvideCredentials;
		}
		RegexpPrecompileSingleton regexpPrecompileSingleton = RegexpPrecompileSingleton.getInstance(regexpList);
		LinkedHashSet<Pattern> regexpSetPrecompile = regexpPrecompileSingleton.precompiledRegexpSet;
		boolean isValid = false;
		String isValidString = "";
		PasswordValidator passwordValidator = new PasswordValidator();
		
		isValid = (passwordValidator.validateRegExp(pwd, regexpSetPrecompile) && passwordValidator.validateSequence(pwd));
		if (isValid) {
			isValidString = Constants.messageIsValidTrue;
		} else {
			StringBuffer sb = new StringBuffer();
			sb.append(Constants.messageIsValidFalse);
			sb.append(Constants.messageProvideCredentials);
			isValidString = sb.toString();
		}
		logger.debug(isValidString);
		return isValidString;
	}
}
