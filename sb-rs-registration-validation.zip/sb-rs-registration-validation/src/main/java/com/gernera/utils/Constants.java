package com.gernera.utils;

public class Constants {
	private Constants() { } // Prevents instantiation 
	public static final String defaultLoginName= "-1";
	public static final String defaultPassword= "-1";
	public static final String messageUnknownUser="Unknown User";
	public static final String regexpLengthAndOccurrence="((?=.*\\d)(?=.*[a-z]).{5,12})";
	public static final String regexpOnlyDigitsAndLowCase="[a-z0-9]+";
	public static final String messageIsValidTrue=" Password is valid.";
	public static final String messageIsValidFalse=" Password is invalid.";
	public static final String messageProvideCredentials=" Please provide LoginName and Password [5-12 characters lower case or numeric, at least one of each. No repeatable sequences]";
	public static final String messageTemplateResponse = "Hello, %s.%s";
	public static final String messageApplicationStarted = "--Application Started--";
	public static final String messageApplicationFinished = "--Application Finished--";
	public static final String messageLoginName = "Login Name = ";
	public static final String messagepPassword = "Password = ";
}
