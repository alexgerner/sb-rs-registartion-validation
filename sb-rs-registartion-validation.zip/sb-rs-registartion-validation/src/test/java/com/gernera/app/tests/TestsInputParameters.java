package com.gernera.app.tests;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.gernera.utils.Constants;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class TestsInputParameters {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void validateNoInputParameters() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " no parameters");
		this.mockMvc.perform(get("/greeting")).andDo(print()).andExpect(status().isOk()).andExpect(jsonPath("$.content")
				.value("Hello, Unknown User. Please provide LoginName and Password [5-12 characters lower case or numeric, at least one of each. No repeatable sequences]"));
	}
	
	@Test
	public void validateInputParamPasswordIsGood() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " parameters good");
		this.mockMvc.perform(get("/greeting?loginName=User&pwd=123abc4")).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.content")
				.value("Hello, User."+Constants.messageIsValidTrue));
	}
	@Test
	public void validateInputParamPasswordIsBad() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " Param Password is bad");
		this.mockMvc.perform(get("/greeting?loginName=User&pwd=123abc4KKK")).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.content")
				.value("Hello, User. Password is invalid. Please provide LoginName and Password [5-12 characters lower case or numeric, at least one of each. No repeatable sequences]"));
	}
	@Test
	public void validateInputParamMissedLoginName() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " parameters bad");
		this.mockMvc.perform(get("/greeting?pwd=123abc4")).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.content")
						.value("Hello, Unknown User. Please provide LoginName and Password [5-12 characters lower case or numeric, at least one of each. No repeatable sequences]"));
	}
	@Test
	public void validateInputParamMissedPassword() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " parameters bad");
		this.mockMvc.perform(get("/greeting?loginName=User")).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.content")
				.value("Hello, User."+Constants.messageProvideCredentials));
	}
}
