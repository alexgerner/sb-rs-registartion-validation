package com.gernera.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class ApplicationControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void validateParamGreeting1() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+ " no parameters");
        this.mockMvc.perform(get("/greeting")).andDo(print())
        		.andExpect(status().isOk())
                .andExpect(jsonPath("$.content").value("Hello, UnknownUser. Please provide LoginName and Password [5-12 characters lower case or numeric, at least one of each. No repeatable sequences]"));
    }

    @Test
    public void validateParamGreeting2() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+ " parameters good");
        this.mockMvc.perform(get("/greeting?loginName=User&pwd=123abc4"))
                .andDo(print()).andExpect(status().isOk())
                .andExpect(jsonPath("$.content").value("Hello, User. Your Password is valid."));
    }
    @Test
    public void validateParamGreeting3() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+ " parameters bad");
        this.mockMvc.perform(get("/greeting?loginName=User&pwd=123abc4KKK"))
                .andDo(print()).andExpect(status().isOk())
                .andExpect(jsonPath("$.content").value("Hello, User. Your Password is invalid. Please provide LoginName and Password [5-12 characters lower case or numeric, at least one of each. No repeatable sequences]"));
    }

   
    
    public void validateRegExp1() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- password is null");
    	String password=null;
     	List<String> regexpList = new ArrayList<String>();
      	regexpList.add(Constants.regexp);
    	PasswordValidator validator = new PasswordValidator();
		Assert.assertFalse(validator.validateRegExp(password, regexpList));

    }
    @Test
    public void validateRegExp2() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- password is empty");
    	String password="";
    	List<String> regexpList = new ArrayList<String>();
      	regexpList.add(Constants.regexp);
    	PasswordValidator validator = new PasswordValidator();
    	Assert.assertFalse(validator.validateRegExp(password, regexpList));

    }
    @Test
    public void validateRegExp3() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- regexp is null");
    	String password="12345";
    	List<String> regexpList = null;
    	PasswordValidator validator = new PasswordValidator();
    	Assert.assertFalse(validator.validateRegExp(password, regexpList));

    }
    @Test
    public void validateRegExp4() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- regexp is empty");
    	String password="12345";
    	List<String> regexpList = new ArrayList<String>();
       	PasswordValidator validator = new PasswordValidator();
    	Assert.assertFalse(validator.validateRegExp(password, regexpList));

    }
    
    @Test
    public void validateRegExp5() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- password is 7 and correct");
    	String password="a12456b";
    	List<String> regexpList = new ArrayList<String>();
      	regexpList.add(Constants.regexp);
       	PasswordValidator validator = new PasswordValidator();   	
    	Assert.assertTrue(validator.validateRegExp(password, regexpList));
    }
    @Test
    public void validateRegExp6() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- password > 12");
    	String password="a1234567891a2345";
    	List<String> regexpList = new ArrayList<String>();
      	regexpList.add(Constants.regexp);
       	PasswordValidator validator = new PasswordValidator();
    	Assert.assertFalse(validator.validateRegExp(password, regexpList));
    }
    @Test
    public void validateRegExp7() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- password = 5 and correct");
    	String password="a1234";
    	List<String> regexpList = new ArrayList<String>();
      	regexpList.add(Constants.regexp);
       	PasswordValidator validator = new PasswordValidator();
    	Assert.assertTrue(validator.validateRegExp(password, regexpList));

    }
    @Test
    public void validateRegExp8() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- password < 5 and correct");
    	String password="a123";
    	List<String> regexpList = new ArrayList<String>();
      	regexpList.add(Constants.regexp);
       	PasswordValidator validator = new PasswordValidator();
    	Assert.assertFalse(validator.validateRegExp(password, regexpList));

    }
    @Test
    public void validateRegExp9() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- password is 5 and Capital Letter");
    	String password="a123SD";
    	List<String> regexpList = new ArrayList<String>();
      	regexpList.add(Constants.regexp1);
       	PasswordValidator validator = new PasswordValidator();
    	Assert.assertFalse(validator.validateRegExp(password, regexpList));

    }
    @Test
    public void validateRegExp10() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- password is 5 and Special Letter");
    	String password="a123//%";
    	List<String> regexpList = new ArrayList<String>();
      	regexpList.add(Constants.regexp1);
       	PasswordValidator validator = new PasswordValidator();
    	Assert.assertFalse(validator.validateRegExp(password, regexpList));
    } 
    
    @Test
    public void testValidateSequence1() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- password is null");
       	String password=null;
    	PasswordValidator validator = new PasswordValidator();
		Assert.assertFalse(validator.validateSequence(password));

    }
    
    @Test
    public void testValidateSequence2() throws Exception {
    	String className = this.getClass().getName();
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- password is empty");
    	String password="";
    	PasswordValidator validator = new PasswordValidator();
		Assert.assertFalse(validator.validateSequence(password));

    }
    
    @Test
    public void testValidateSequence3() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- repeated sequence included");
    	String password="abc1c123ab";
    	PasswordValidator validator = new PasswordValidator();
		Assert.assertFalse(validator.validateSequence(password));

    }
    @Test
    public void testValidateSequence4() throws Exception {
    	String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
    	System.out.println(methodName+"- repeated sequence not included");
    	String password="abc123ab";
    	PasswordValidator validator = new PasswordValidator();
		Assert.assertTrue(validator.validateSequence(password));

    }
    
   
}
