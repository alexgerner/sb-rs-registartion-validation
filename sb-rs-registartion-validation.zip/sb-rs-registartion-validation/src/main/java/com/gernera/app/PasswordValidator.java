package com.gernera.app;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordValidator {
	private boolean isValid = true;
	private String template = null;
	
	public boolean validateRegExp(final String password, final String  regexp) {
		Pattern p = Pattern.compile(regexp);
		Matcher m = p.matcher(password);
		if (m.matches()) {
			return true;
		}
		else {
			return false;
		}
	}
	public boolean validateRegExp(final String password, final List<String> regexpList) {
		if (password==null||password.length()==0||regexpList==null||regexpList.size()==0) {
			isValid = false;
			return isValid;
		}
		Set<String> regexpSet = new HashSet<String>(regexpList); // elimmite dupicates
		for (String regexp : regexpSet) {
			Pattern p = Pattern.compile(regexp);
			Matcher m = p.matcher(password);
			if (m.matches())
				continue;
			else {
				isValid = false;
				return isValid;
			}
		}
		return isValid;
	}

	public boolean validateSequence(final String password) {
		if (password==null) {
			isValid = false;
			return isValid;
		}
		template = password;
		int templateLenght = template.length();
		if (templateLenght<=0) {
			isValid = false;
			return isValid;
		}
		for (int i = 0; i < templateLenght; i++) {
			char c = template.charAt(i);

			String substr = template.substring(i + 1);
			int index = substr.indexOf(c);
			if (index == -1) {
				continue;
			} else {
				String substringBefore = template.substring(i, i + index + 1);
				int to=i + index + 1+substringBefore.length();
				if (to>templateLenght) {
					to=templateLenght;
				}
				String substringAfter = template.substring(i + index + 1,to);
				if (substringBefore.equals(substringAfter)) {
					isValid = false;
					return isValid;
				} else {
					continue;
				}
			}

		}

		return isValid;
	}

}
