package com.gernera.app;

public class Constants {
	private Constants() { } // Prevents instantiation 
	public static final String regexp="((?=.*\\d)(?=.*[a-z]).{5,12})";
	public static final String regexp1="[a-z0-9]+";
	public static final String isValidTrue=" Your Password is valid.";
	public static final String isValidFalse=" Your Password is invalid.";
	public static final String provideCredentials=" Please provide LoginName and Password [5-12 characters lower case or numeric, at least one of each. No repeatable sequences]";


}
