package com.gernera.app;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gernera.app.ApplicationProperties;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

@RestController
public class ApplicationController {
	
	@Autowired
	private static final Logger logger = LoggerFactory.getLogger(ApplicationController.class);
    private static final String template = "Hello, %s.%s";
    @Autowired
	private ApplicationProperties applicationProperties; 
    @RequestMapping("/greeting")
    public Greeting greeting(@RequestParam(value="loginName", defaultValue="UnknownUser") String loginName, @RequestParam(value="pwd", defaultValue="abcd123") String pwd) {
    	logger.info("--Application Started--");
    	logger.info("--loginName="+loginName+"--");
    	logger.debug("--pwd="+pwd+"--");
      	List<String> regexpList = applicationProperties.getRegexp();
      	PasswordValidator validator = new PasswordValidator();
      	boolean isValid = false;
      	if (loginName.equals("UnknownUser")) {		
            	return new Greeting(String.format(template, loginName, Constants.provideCredentials));
      	}
      	isValid=(validator.validateRegExp(pwd, regexpList)&&validator.validateSequence(pwd));
       	String isValidString = Constants.isValidFalse+Constants.provideCredentials;
       	if (isValid) isValidString = Constants.isValidTrue;
       	logger.info("--isValid="+isValid+"--");
       	logger.info("--Application Finished--");
      
    	return new Greeting(String.format(template, loginName, isValidString));
    }
}
