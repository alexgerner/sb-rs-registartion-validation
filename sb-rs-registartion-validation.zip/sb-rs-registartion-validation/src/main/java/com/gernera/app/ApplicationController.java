package com.gernera.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import com.gernera.utils.Constants;

@RestController
public class ApplicationController {
	
	private static final Logger logger = LoggerFactory.getLogger(ApplicationController.class);

    @Autowired
    private AuthenticationService authenticationService;
    @RequestMapping("/greeting")
    public Greeting greeting(@RequestParam(value="loginName", defaultValue=Constants.defaultLoginName) String loginName, @RequestParam(value="pwd", defaultValue=Constants.defaultPassword) String pwd) {
    	logger.info(Constants.messageApplicationStarted);   
    	logger.info(Constants.messageLoginName+loginName);
    	String result=authenticationService.executeService(loginName, pwd);
    	loginName = loginName.contentEquals("-1") ? Constants.messageUnknownUser:loginName; 
    	logger.info(Constants.messageApplicationFinished);
       	return new Greeting(String.format(Constants.messageTemplateResponse, loginName, result));
    }
}
