package com.gernera.utils;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

public final class RegexpPrecompileSingleton { 
	private static RegexpPrecompileSingleton regexpPrecomileSingleInstance = null; 
    public LinkedHashSet<Pattern> precompiledRegexpSet;
    private RegexpPrecompileSingleton(List<String> regexpList) {
        LinkedHashSet<String> regexpSet = new LinkedHashSet<String>(regexpList); // elimmite dupicates
    			LinkedHashSet<Pattern> regexpSetPrecomile = new LinkedHashSet<Pattern>();
    			for (String regexp : regexpSet) {
    				regexpSetPrecomile.add(Pattern.compile(regexp));
    			}
    		this.precompiledRegexpSet=regexpSetPrecomile;
    }

    public static RegexpPrecompileSingleton getInstance(List<String> regexpList) {
        if (regexpPrecomileSingleInstance == null) {
        	regexpPrecomileSingleInstance = new RegexpPrecompileSingleton(regexpList);
        }
        return regexpPrecomileSingleInstance;
    }
}