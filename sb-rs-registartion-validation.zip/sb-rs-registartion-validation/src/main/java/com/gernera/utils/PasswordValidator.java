package com.gernera.utils;

import java.util.LinkedHashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordValidator {

	public boolean validateRegExp(final String password, final LinkedHashSet<Pattern> regexpSetPrecomile) {
		if (password == null || password.length() == 0 || regexpSetPrecomile == null
				|| regexpSetPrecomile.size() == 0) {
			return false;
		}
		for (Pattern pattern : regexpSetPrecomile) {
			Matcher m = pattern.matcher(password);
			if (!m.matches()) {
				return false;
			}
		}
		return true;
	}

	public boolean validateSequence(final String template) {
		if (template == null || template.length() == 0) {
			return false;
		}
		int templateLength = template.length();
		for (int i = 0; i < templateLength; i++) {
			char c = template.charAt(i);
			String substr = template.substring(i + 1);
			int index = substr.indexOf(c);
			if (index == -1) {
				continue;
			} else {
				String substringBefore = template.substring(i, i + index);
				int to = i + index + 1 + substringBefore.length();
				if (to > templateLength) {
					to = templateLength;
				}
				String substringAfter = template.substring(i + index + 1, to);
				if (substringBefore.equals(substringAfter)) {
					return false;
				} 
			}

		}
		return true;
	}

}
